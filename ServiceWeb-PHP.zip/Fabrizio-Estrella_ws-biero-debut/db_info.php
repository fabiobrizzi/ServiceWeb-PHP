<?php
define('HOST', 'localhost');
define('PASSWORD', 'root');
define('USER', 'root');
define('DATABASE', 'biero');

?>